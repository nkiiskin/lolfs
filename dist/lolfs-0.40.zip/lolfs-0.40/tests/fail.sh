#!/bin/sh
echo "Test failed"
exit -1
