#!/bin/sh
echo "Test succesful"
exit 0
