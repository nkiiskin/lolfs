#!/bin/sh
echo "Dang: FAILED"
exit -1
